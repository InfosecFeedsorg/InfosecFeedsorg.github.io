# InfosecFeedsorg.github.io
Infosec Security dfir related podcasts - "Planet" feed-of-feeds RSS ATOM web-based index of non-exclusively-commercial based security-related podcasts

#
#

\\\Treat each other awesomely -> "What are RSS feeds?"  Well, in this case it's like a web-based podcather, or place to summarize and index all the security-related podcasts.  

Initially this was just a side-effect of gradually beginning to share personal blogs (blog.infosecfeeds.org) and the Computer Forensics Podcast (dfir.infosecfeeds.org or podcast.infosecfeeds.org), so I ended up with the url, and aftera few conversations on twitter (reposted to  @infosecfeedsorg) about how an index or more lists of all "infosec" related security podcasts would be cool, we created this.

Use cases for the site might be discovered, but Love each other is number one!  A more tangible example of use would be when you prefer to be browser-based, or even on ChromeOS or similar, and/or also you want to avoiding adding mysery extentions or cloud based RSS-readers. ...or to also discover new podcasts, or save time going through so many different podcast feeds. 

There is no exclusive club.  We'll add most anything people suggest on the site or via twitter; however we'll avoid anything that is mostly based upon a single-vendor or product, which does not frequntly tie-in to nice coversations about networking or security in general. Also other than the site's own dfir blog, it is meant to be a feed of podcasts, not blogs.  I'll try and link out to other such "blog" lists though. Hopefully this can be also eventually a way for nice podcasts to get easily discovered and mixed in with, what is right now, a surprisingly small, but high-quality group of infosec podcasters.  

\\ This is based on planet (used originally for bringing together planet debian and planet gnome, which collect the rich community of blogs from those projects, into single RSS and other feeds.  see http://planetplanet.org and https://people.gnome.org/~jdub/bzr/planet/devel/trunk/

\ I may add much more to the list as people reach out, and from my own lists; for now this is only the quick, starting point!
